# Ego Cutz Barbershop — egocutz.com

Fully static one-page site: `index.html` + `css/styles.css` + `js/script.js`.
No build step. Deploy the `egocutz-site/` folder to any static host and point
`egocutz.com` at it (serve directly — do not keep the redirect-only setup).

## Stack

- **Fonts (self-hosted, `assets/fonts/`)**: Big Shoulders (display, OFL via
  Google Fonts), Satoshi (body, ITF Free Font License via Fontshare),
  Instrument Serif italic (accent, OFL).
- **Animation**: GSAP 3.13 + ScrollTrigger, vendored in `js/vendor/` (GSAP is
  free under its standard license). All motion is transform/opacity only and
  respects `prefers-reduced-motion`. Append `?noanim` to the URL to disable
  all scripted animation (debug aid).
- **Instagram**: official embeds (`instagram.com/embed.js`), lazy-loaded via
  IntersectionObserver only when the gallery approaches the viewport. Posts
  are a curated allowlist — no auto-feed.
- **Hero photos (`assets/img/`)**: INTERIM derivatives from the research
  archive, chosen from the curation report's ranked shortlist —
  `hero-mobile.jpg` (= Linktree `appointments-with-zack-original.jpeg`),
  `color.jpg` (= Instagram `DZ-N5eQllVq/01.jpg`), `chair.jpg`
  (= Instagram `DPBpr0RAI3t/04.jpg`), and `shop.jpg`
  (= `DPBpr0RAI3t/09.jpg`). The 1000×1000 action portrait is art-directed into
  a 4:5 mobile lead; the environmental `hero-bg.jpg` remains the wider
  breakpoint backdrop and now supports Zack's About story.
  The grand-opening shots are credited to `@picgrasshopper`; the service
  result also includes an identifiable client. **Written image rights and
  client releases are required before public launch** (see
  visual-content-curation.md). Replace with cleared/new-shoot masters.
- **Booking**: Square Appointments deep link (unchanged backend).

## Design tokens

| Token | Value | Role |
|---|---|---|
| ink | `#100B0A` | page ground (red-biased near-black) |
| coal | `#1C1412` | raised surfaces |
| bone | `#EFE7DC` | menu-board paper / light text |
| blood | `#E63B2B` | signal red (large type & CTAs on dark) |
| oxblood | `#9E1B14` | deep red on bone (AA-safe) |
| chrome | `#A89E95` | secondary text on dark |

## Before public launch (from the research package)

These are **not done** and block a real launch — see
`../research/egocutz/reports/questions-for-zack.md`:

1. Zack must confirm: name spelling (Zack/Zak), legal footer ("Ego Cuts, LLC"),
   slogan treatment, Sept 2025 opening date, hours, phone/text policy.
2. Service names/prices/durations must be reconciled with the live Square
   account before this menu is treated as authoritative (site shows "from"
   pricing + consult notes to stay honest).
3. Instagram embed allowlist should be re-approved by Zack; embeds referencing
   young-looking clients were deliberately excluded.
4. The multi-service booking contradiction (banner vs. Square config) needs
   one decision; copy currently says "call first."
5. DNS: serve this site at the apex, 301 `www` → apex preserving path+query;
   publish `robots.txt` + `sitemap.xml` at the custom domain.
